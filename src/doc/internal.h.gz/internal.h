{\rtf1\mac\ansicpg10000\cocoartf824\cocoasubrtf330
{\fonttbl\f0\fswiss\fcharset77 Arial-BoldMT;\f1\fswiss\fcharset77 ArialMT;\f2\fswiss\fcharset77 Arial-ItalicMT;
\f3\fnil\fcharset77 Verdana;\f4\fnil\fcharset77 Verdana-Bold;\f5\fmodern\fcharset109 Courier;
\f6\fnil\fcharset77 Verdana-Italic;\f7\fswiss\fcharset77 Optima-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green37\blue250;}
\margl1440\margr1440\vieww13560\viewh17880\viewkind0
\deftab720
\pard\pardeftab720\ql\qnatural

\f0\b\fs32 \cf0 Overriding New and Delete
\f1\b0 \
\pard\pardeftab720\ql\qnatural

\f2\i\fs26 \cf0 By Danny Kalev
\f1\i0 \
\
\pard\pardeftab720\sa260\ql\qnatural

\f3 \cf0 For most programming tasks, the default implementation of operators 
\f4\b new
\f3\b0  and 
\f4\b delete
\f3\b0  is sufficient. In fact, many C++ programmers get along without even knowing they can override these operators. However, in certain application domains and advanced programming tasks, redefining these operators for a given class is essential, e.g., when you want to ensure that all instances of that class are allocated from a custom memory pool instead of being allocated on the free-store (although you can use {\field{\*\fldinst{HYPERLINK "http://www.inquiry.com/techtips/cpp_pro/10min/10min0999.asp"}}{\fldrslt \cf2 placement new}} for this purpose, it doesn't block users from using global overriding new and delete).\
There are other uses for overriding new and delete such as implementing a {\field{\*\fldinst{HYPERLINK "http://www.hpl.hp.com/personal/Hans_Boehm/gc"}}{\fldrslt \cf2 garbage collector}} and memory leak detectors. Furthermore, certain applications require that objects be allocated on a specific memory address, e.g., a video card's internal buffer. For all these applications, overriding 
\f4\b new
\f3\b0  and 
\f4\b delete
\f3\b0  is necessary. I will show how to override these operators, first on a per-class basis, and then globally.\

\f4\b Step 1: Declaring New and Delete as Class Members
\f3\b0 \uc0\u8232 Suppose we want to override new and delete for class C. Our first step is to declare these operators as C's member functions:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u110 \u101 \u119 \u62 \u32 \u47 \u47 \u32 \u102 \u111 \u114 \u32 \u115 \u105 \u122 \u101 \u95 \u116 \
\uc0\u99 \u108 \u97 \u115 \u115 \u32 \u67 \u32 \
\uc0\u123 \
\uc0\u112 \u117 \u98 \u108 \u105 \u99 \u58 \
\uc0\u32 \u67 \u40 \u41 \u59 \u32 \
\uc0\u32 \u126 \u67 \u40 \u41 \u59 \
\uc0\u32 \u115 \u116 \u97 \u116 \u105 \u99 \u32 \u118 \u111 \u105 \u100 \u42 \u32 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u110 \u101 \u119 \u32 \u40 \u115 \u105 \u122 \u101 \u95 \u116 \u32 \u115 \u105 \u122 \u101 \u41 \u59 \u32 \
\uc0\u32 \u115 \u116 \u97 \u116 \u105 \u99 \u32 \u118 \u111 \u105 \u100 \u32 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u40 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u41 \u59 \
\uc0\u125 \u59 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 The new and delete member functions are implicitly declared static. Nevertheless, we declare them static to document this property explicitly.\

\f4\b Step 2: Implementation
\f3\b0 \uc0\u8232 The implementation of new is straightforward: it calls a custom allocation function, say, allocate_from_pool(), and returns the resulting pointer. You can use any other memory allocation function that suits your needs, e.g., malloc(), GlobalAlloc(), etc. Here's the definition of the overriding new:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u118 \u111 \u105 \u100 \u42 \u32 \u67 \u58 \u58 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u110 \u101 \u119 \u32 \u40 \u115 \u105 \u122 \u101 \u95 \u116 \u32 \u32 \u115 \u105 \u122 \u101 \u41 \
\uc0\u123 \
\uc0\u32 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u61 \u97 \u108 \u108 \u111 \u99 \u97 \u116 \u101 \u95 \u102 \u114 \u111 \u109 \u95 \u112 \u111 \u111 \u108 \u40 \u115 \u105 \u122 \u101 \u41 \u59 \
\uc0\u32 \u114 \u101 \u116 \u117 \u114 \u110 \u32 \u112 \u59 \u32 \
\uc0\u125 \u32 \u47 \u47 \u32 \u67 \u39 \u115 \u32 \u100 \u101 \u102 \u97 \u117 \u108 \u116 \u32 \u99 \u111 \u110 \u115 \u116 \u114 \u117 \u99 \u116 \u111 \u114 \u32 \u105 \u109 \u112 \u108 \u105 \u99 \u105 \u116 \u108 \u121 \u32 \u99 \u97 \u108 \u108 \u101 \u100 \u32 \u104 \u101 \u114 \u101 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 When new exits, the class's default constructor executes automatically and constructs the object. \uc0\u8232 The matching version of delete is as follows:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u118 \u111 \u105 \u100 \u32 \u67 \u58 \u58 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u40 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u41 \
\uc0\u123 \u9 \
\uc0\u32 \u114 \u101 \u108 \u101 \u97 \u115 \u101 \u40 \u112 \u41 \u59 \u32 \u47 \u47 \u32 \u114 \u101 \u116 \u117 \u114 \u110 \u32 \u109 \u101 \u109 \u111 \u114 \u121 \u32 \u116 \u111 \u32 \u112 \u111 \u111 \u108 \
\uc0\u125 \u32 \u47 \u47 \u32 \u67 \u39 \u115 \u32 \u100 \u101 \u115 \u116 \u114 \u117 \u99 \u116 \u111 \u114 \u32 \u105 \u109 \u112 \u108 \u105 \u99 \u105 \u116 \u108 \u121 \u32 \u99 \u97 \u108 \u108 \u101 \u100 \u32 \u97 \u116 \u32 \u116 \u104 \u105 \u115 \u32 \u112 \u111 \u105 \u110 \u116 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 C++ guarantees that an object's destructor is automatically called right before delete executes. Therefore, we don't invoke C's destructor explicitly (doing so would cause undefined behavior as the destructor will actually run twice).\

\f4\b Additional Customizations
\f3\b0 \uc0\u8232 Overriding new enables us to customize its functionality in various ways. For instance, we can add an error handling mechanism to our implementation by defining a special exception class, mem_exception. An object of this class will be thrown in case of a failure:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u99 \u108 \u97 \u115 \u115 \u32 \u109 \u101 \u109 \u95 \u101 \u120 \u99 \u101 \u112 \u116 \u105 \u111 \u110 \u32 \u123 \u125 \u59 \u32 \
\uc0\u118 \u111 \u105 \u100 \u42 \u32 \u67 \u58 \u58 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u110 \u101 \u119 \u32 \u40 \u115 \u105 \u122 \u101 \u95 \u116 \u32 \u32 \u115 \u105 \u122 \u101 \u41 \
\uc0\u123 \
\uc0\u32 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u61 \u97 \u108 \u108 \u111 \u99 \u97 \u116 \u101 \u95 \u102 \u114 \u111 \u109 \u95 \u112 \u111 \u111 \u108 \u40 \u115 \u105 \u122 \u101 \u41 \u59 \
\uc0\u32 \u105 \u102 \u32 \u40 \u112 \u61 \u61 \u48 \u41 \
\uc0\u32 \u32 \u32 \u116 \u104 \u114 \u111 \u119 \u32 \u109 \u101 \u109 \u95 \u101 \u120 \u99 \u101 \u112 \u116 \u105 \u111 \u110 \u40 \u41 \u59 \
\uc0\u32 \u114 \u101 \u116 \u117 \u114 \u110 \u32 \u112 \u59 \
\uc0\u125 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 In a similar vein, we can extend delete's functionality to report the amount of available memory, write a message to a log file, and so on:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u99 \u116 \u105 \u109 \u101 \u62 \u32 \u47 \u47 \u32 \u102 \u111 \u114 \u32 \u116 \u105 \u109 \u101 \u40 \u41 \
\uc0\u118 \u111 \u105 \u100 \u32 \u67 \u58 \u58 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u40 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u41 \
\uc0\u123 \u9 \
\uc0\u32 \u114 \u101 \u108 \u101 \u97 \u115 \u101 \u40 \u112 \u41 \u59 \u32 \
\uc0\u32 \u99 \u111 \u117 \u116 \u32 \u60 \u60 \u32 \u34 \u97 \u118 \u97 \u105 \u108 \u97 \u98 \u108 \u101 \u32 \u112 \u111 \u111 \u108 \u32 \u115 \u105 \u122 \u101 \u58 \u32 \u34 \u32 \u60 \u60 \u32 \u103 \u101 \u116 \u95 \u112 \u111 \u111 \u108 \u95 \u115 \u105 \u122 \u101 \u40 \u41 \u59 \
\uc0\u32 \u119 \u114 \u105 \u116 \u101 \u95 \u116 \u111 \u95 \u108 \u111 \u103 \u40 \u34 \u100 \u101 \u108 \u101 \u116 \u105 \u111 \u110 \u32 \u111 \u99 \u99 \u117 \u114 \u114 \u101 \u100 \u32 \u97 \u116 \u58 \u32 \u34 \u44 \u32 \u116 \u105 \u109 \u101 \u40 \u48 \u41 \u41 \u59 \
\uc0\u125 \
\pard\pardeftab720\sa260\ql\qnatural

\f4\b\fs26 \cf0 Step 3: Using the Overriding Operators
\f3\b0 \uc0\u8232 We use the overriding new and delete as we use the default new and delete; C++ automatically chooses the overriding versions if they exist. Classes for which no overriding versions are defined continue to use the default new and delete:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u105 \u110 \u116 \u32 \u109 \u97 \u105 \u110 \u40 \u41 \u32 \
\uc0\u123 \u32 \
\uc0\u32 \u67 \u32 \u42 \u112 \u61 \u110 \u101 \u119 \u32 \u67 \u59 \u32 \u47 \u47 \u32 \u67 \u58 \u58 \u110 \u101 \u119 \
\uc0\u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u112 \u59 \u32 \u47 \u47 \u32 \u67 \u58 \u58 \u100 \u101 \u108 \u101 \u116 \u101 \
\uc0\u32 \u105 \u110 \u116 \u32 \u42 \u112 \u61 \u110 \u101 \u119 \u32 \u105 \u110 \u116 \u59 \u32 \u47 \u47 \u32 \u58 \u58 \u110 \u101 \u119 \
\uc0\u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u112 \u59 \u32 \u47 \u47 \u32 \u58 \u58 \u100 \u101 \u108 \u101 \u116 \u101 \
\uc0\u125 \
\pard\pardeftab720\sa260\ql\qnatural

\f4\b\fs26 \cf0 Step 4: Overriding New and Delete Globally
\f3\b0 \uc0\u8232 Up until now, we've focused on a class-based override. What if we want override new and delete not just for one class, but for the entire application? C++ allows us to do that, too, by defining global versions of these operators. Unlike a class-based override, the global new and delete are declared in the global namespace. This technique may be particularly useful for Visual C++ users. As you probably know, the implementation of new in Visual C++ {\field{\*\fldinst{HYPERLINK "http://support.microsoft.com/support/kb/articles/Q167/7/33.ASP"}}{\fldrslt \cf2 isn't standard compliant}}: new returns a null pointer upon failure instead of throwing a std::bad_alloc exception, as required by the C++ ANSI/ISO standard. The following example overrides global new and delete to force standard compliant behavior. Visual C++ users wishing to fix their {\field{\*\fldinst{HYPERLINK "http://support.microsoft.com/support/kb/articles/q243/4/51.ASP"}}{\fldrslt \cf2 laggard implementation}} can use it:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u101 \u120 \u99 \u101 \u112 \u116 \u105 \u111 \u110 \u62 \u32 \u47 \u47 \u32 \u102 \u111 \u114 \u32 \u115 \u116 \u100 \u58 \u58 \u98 \u97 \u100 \u95 \u97 \u108 \u108 \u111 \u99 \
\uc0\u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u110 \u101 \u119 \u62 \
\uc0\u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u99 \u115 \u116 \u100 \u108 \u105 \u98 \u62 \u32 \u47 \u47 \u32 \u102 \u111 \u114 \u32 \u109 \u97 \u108 \u108 \u111 \u99 \u40 \u41 \u32 \u97 \u110 \u100 \u32 \u102 \u114 \u101 \u101 \u40 \u41 \
\
\uc0\u47 \u47 \u32 \u86 \u105 \u115 \u117 \u97 \u108 \u32 \u67 \u43 \u43 \u32 \u102 \u105 \u120 \u32 \u111 \u102 \u32 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u110 \u101 \u119 \
\
\uc0\u118 \u111 \u105 \u100 \u42 \u32 \u67 \u58 \u58 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u110 \u101 \u119 \u32 \u40 \u115 \u105 \u122 \u101 \u95 \u116 \u32 \u115 \u105 \u122 \u101 \u41 \
\uc0\u123 \
\uc0\u32 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u61 \u109 \u97 \u108 \u108 \u111 \u99 \u40 \u115 \u105 \u122 \u101 \u41 \u59 \u32 \
\uc0\u32 \u105 \u102 \u32 \u40 \u112 \u61 \u61 \u48 \u41 \u32 \u47 \u47 \u32 \u100 \u105 \u100 \u32 \u109 \u97 \u108 \u108 \u111 \u99 \u32 \u115 \u117 \u99 \u99 \u101 \u101 \u100 \u63 \
\uc0\u32 \u32 \u32 \u116 \u104 \u114 \u111 \u119 \u32 \u115 \u116 \u100 \u58 \u58 \u98 \u97 \u100 \u95 \u97 \u108 \u108 \u111 \u99 \u40 \u41 \u59 \u32 \u47 \u47 \u32 \u65 \u78 \u83 \u73 \u47 \u73 \u83 \u79 \u32 \u99 \u111 \u109 \u112 \u108 \u105 \u97 \u110 \u116 \u32 \u98 \u101 \u104 \u97 \u118 \u105 \u111 \u114 \
\uc0\u32 \u114 \u101 \u116 \u117 \u114 \u110 \u32 \u112 \u59 \
\uc0\u125 \
\
\uc0\u84 \u104 \u101 \u32 \u109 \u97 \u116 \u99 \u104 \u105 \u110 \u103 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u105 \u115 \u32 \u97 \u115 \u32 \u102 \u111 \u108 \u108 \u111 \u119 \u115 \u58 \
\
\uc0\u118 \u111 \u105 \u100 \u32 \u111 \u112 \u101 \u114 \u97 \u116 \u111 \u114 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u40 \u118 \u111 \u105 \u100 \u32 \u42 \u112 \u41 \
\uc0\u123 \
\uc0\u32 \u102 \u114 \u101 \u101 \u40 \u112 \u41 \u59 \u32 \
\uc0\u125 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 Now you can use try and catch blocks to handle potential allocation exceptions properly, even if your compiler isn't yet fully compliant:\
\
\pard\pardeftab720\ql\qnatural

\f5\fs22\fsmilli11375 \cf0 \uc0\u105 \u110 \u116 \u32 \u109 \u97 \u105 \u110 \u40 \u41 \
\uc0\u123 \
\uc0\u32 \u116 \u114 \u121 \
\uc0\u32 \u123 \
\uc0\u32 \u32 \u105 \u110 \u116 \u32 \u42 \u112 \u61 \u110 \u101 \u119 \u32 \u105 \u110 \u116 \u91 \u49 \u48 \u48 \u48 \u48 \u48 \u48 \u48 \u93 \u59 \u32 \u47 \u47 \u32 \u117 \u115 \u101 \u114 \u45 \u100 \u101 \u102 \u105 \u110 \u101 \u100 \u32 \u110 \u101 \u119 \
\uc0\u32 \u32 \u47 \u47 \u46 \u46 \u117 \u115 \u101 \u32 \u112 \
\uc0\u32 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u112 \u59 \u32 \u47 \u47 \u32 \u117 \u115 \u101 \u114 \u45 \u100 \u101 \u102 \u105 \u110 \u101 \u100 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \
\uc0\u32 \u125 \
\uc0\u32 \u99 \u97 \u116 \u99 \u104 \u32 \u40 \u115 \u116 \u100 \u58 \u58 \u98 \u97 \u100 \u95 \u97 \u108 \u108 \u111 \u99 \u32 \u38 \u32 \u120 \u41 \
\uc0\u32 \u123 \
\uc0\u32 \u32 \u115 \u116 \u100 \u58 \u58 \u99 \u111 \u117 \u116 \u32 \u60 \u60 \u32 \u120 \u46 \u119 \u104 \u97 \u116 \u40 \u41 \u59 \u32 \u47 \u47 \u32 \u100 \u105 \u115 \u112 \u108 \u97 \u121 \u32 \u101 \u120 \u99 \u101 \u112 \u116 \u105 \u111 \u110 \
\uc0\u32 \u125 \
\uc0\u125 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs26 \cf0 Very few programming languages allow you to access and modify their inner-workings as does C++. Indeed, overriding new and delete is a very powerful feature\'d1it gives you tighter control over the language's memory management policy and enables you to extend its functionality in various ways. However, the default implementation of new and delete is suitable for most purposes; don't override these operators unless you have compelling reasons to do so, and when doing so, remember always to override both of them.\
\
\
\
\

\f0\b\fs32 Constructing an Object at a Pre-Determined Memory Position
\f1\b0 \
\pard\pardeftab720\ql\qnatural

\f2\i\fs26 \cf0 By Danny Kalev
\f1\i0 \
\
\pard\pardeftab720\sa260\ql\qnatural

\f3 \cf0 One of the frequently asked questions in various C++ newsgroups is, "How can I create an object on a pre-determined memory address?" Constructing an object on a previously-allocated memory buffer has many useful applications. For example, a custom garbage collector can use a large pre-allocated memory buffer on which users can construct their objects. When these objects are no longer needed, their storage is automatically reclaimed.\
This technique is also useful in time-critical applications. Constructing an object on a pre-allocated buffer is a constant-time operation because the program does not waste precious time on the allocation operation itself. Note also that dynamic memory allocation might fail when the system has insufficient memory. Thus, for mission critical applications, pre-allocating a sufficiently large buffer is sometimes avoidable.\
Finally, many applications need to construct a different type of object at a given time (think of a GUI application that displays a different dialog box every time, according to user's input). Instead of using repeated allocations and de-allocations of memory, the application can create in advance a buffer of memory on which a different type of object can be constructed and destroyed cyclically.\
C++ provides several features to facilitate the task of constructing an object at a pre-determined memory position. These features include a special form of operator new called 
\f6\i placement new
\f3\i0 , and an 
\f6\i explicit destructor invocation
\f3\i0 . The following demonstrates how this is actually done.\
The first step consists of allocating a memory buffer large enough to store an object of the desired type. (If you intend to construct a different type of object every time, you need to allocate a buffer that is at least as large as the largest object). The pre-allocated buffer is a plain char array allocated on the free store:
\f5\fs28 \
\uc0\u32 \u32 \u99 \u104 \u97 \u114 \u32 \u42 \u32 \u98 \u117 \u102 \u102 \u32 \u61 \u32 \u110 \u101 \u119 \u32 \u99 \u104 \u97 \u114 \u32 \u91 \u115 \u105 \u122 \u101 \u111 \u102 \u32 \u40 \u70 \u111 \u111 \u41 \u32 \u93 \u59 \
\pard\pardeftab720\sa260\ql\qnatural

\f3\fs32 \cf0 Once you have allocated the buffer, you can construct every type of object on it. For that purpose, you use a special version of operator new, placement new, which takes the address of the pre-allocated buffer as an argument. To use placement new, you have to #include the standard header <new>. In the following code snippet, an object of type Foo is allocated on the memory address of buff using placement new:
\f5\fs28 \
\uc0\u32 \u32 \u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u110 \u101 \u119 \u62 \
\uc0\u32 \u32 \u70 \u111 \u111 \u32 \u42 \u32 \u112 \u102 \u111 \u111 \u32 \u61 \u32 \u110 \u101 \u119 \u32 \u40 \u98 \u117 \u102 \u102 \u41 \u32 \u70 \u111 \u111 \u59 \u32 \u47 \u47 \u99 \u111 \u110 \u115 \u116 \u114 \u117 \u99 \u116 \u32 \u97 \u32 \u70 \u111 \u111 \u32 \u111 \u110 \u32 \u98 \u117 \u102 \u102 \u32 \u117 \u115 \u105 \u110 \u103 \u32 \u112 \u108 \u97 \u99 \u101 \u109 \u101 \u110 \u116 \u32 \u110 \u101 \u119 \

\f3\fs32 Placement new takes the address of a previously allocated buffer and constructs an object of the requested type on that buffer. It returns a pointer to the constructed object. You use this pointer as an ordinary pointer of the requested type:
\f5\fs28 \
\uc0\u32 \u32 \u117 \u110 \u115 \u105 \u103 \u110 \u101 \u100 \u32 \u105 \u110 \u116 \u32 \u108 \u101 \u110 \u103 \u116 \u104 \u32 \u61 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u115 \u105 \u122 \u101 \u40 \u41 \u59 \u32 \u32 \
\uc0\u32 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u114 \u101 \u115 \u105 \u122 \u101 \u40 \u49 \u48 \u48 \u44 \u32 \u50 \u48 \u48 \u41 \u59 \
\uc0\u32 \u32 \u108 \u101 \u110 \u103 \u116 \u104 \u32 \u61 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u115 \u105 \u122 \u101 \u40 \u41 \u59 \u32 \

\f3\fs32 When the object is not needed anymore, you have to invoke its destructor explicitly. This part is somewhat tricky, because many people falsely assume that the object is destroyed automatically, which it isn't. If you forget to explicitly invoke the destructor before you construct another object on the pre-allocated buffer or before you release the buffer, the program's behavior is undefined. The explicit destructor invocation looks like this:
\f5\fs28 \
\uc0\u32 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u126 \u70 \u111 \u111 \u40 \u41 \u59 \u32 \u47 \u47 \u101 \u120 \u112 \u108 \u105 \u99 \u105 \u116 \u32 \u100 \u101 \u115 \u116 \u114 \u117 \u99 \u116 \u111 \u114 \u32 \u105 \u110 \u118 \u111 \u99 \u97 \u116 \u105 \u111 \u110 \

\f3\fs32 In other words, an explicit destructor invocation is similar to an ordinary member function call, except that the name of the member function is the name of the class preceded by a tilde. Once the object has been destroyed, you can use the pre-allocated buffer again to construct another object on it. In fact, this process can be repeated infinitely: You construct an object, destroy it, and recycle the pre-allocated buffer once more.
\fs26 \
\pard\pardeftab720\sa320\ql\qnatural

\fs32 \cf0 When the pre-allocated buffer is not needed anymore, or when the application is closed, you have to release the pre-allocated buffer. Recall that you need to use delete[] for that purpose, as the pre-allocated buffer is an array of char. The following snippet contains a complete example of all the steps shown so far, as well as the final release of the buffer:
\f5\fs28 \
\uc0\u32 \u32 \u35 \u105 \u110 \u99 \u108 \u117 \u100 \u101 \u32 \u60 \u110 \u101 \u119 \u62 \
\
\uc0\u32 \u32 \u118 \u111 \u105 \u100 \u32 \u112 \u108 \u97 \u99 \u101 \u109 \u101 \u110 \u116 \u95 \u100 \u101 \u109 \u111 \u40 \u41 \
\uc0\u32 \u32 \u123 \u32 \
\uc0\u32 \u32 \u32 \u32 \u99 \u104 \u97 \u114 \u32 \u42 \u32 \u98 \u117 \u102 \u102 \u32 \u61 \u32 \u110 \u101 \u119 \u32 \u99 \u104 \u97 \u114 \u32 \u91 \u115 \u105 \u122 \u101 \u111 \u102 \u32 \u40 \u70 \u111 \u111 \u41 \u32 \u93 \u59 \u32 \u32 \u47 \u47 \u49 \u46 \u32 \u112 \u114 \u101 \u45 \u97 \u108 \u108 \u111 \u99 \u97 \u116 \u101 \u32 \u98 \u117 \u102 \u102 \u101 \u114 \
\uc0\u32 \u32 \u32 \u32 \u70 \u111 \u111 \u32 \u42 \u32 \u112 \u102 \u111 \u111 \u32 \u61 \u32 \u110 \u101 \u119 \u32 \u40 \u98 \u117 \u102 \u102 \u41 \u32 \u70 \u111 \u111 \u59 \u32 \u32 \u47 \u47 \u50 \u46 \u32 \u117 \u115 \u101 \u32 \u112 \u108 \u97 \u99 \u101 \u109 \u101 \u110 \u116 \u32 \u110 \u101 \u119 \
\uc0\u32 \u32 \u32 \u32 \u32 \u32 \u47 \u47 \u117 \u115 \u101 \u32 \u116 \u104 \u101 \u32 \u111 \u98 \u106 \u101 \u99 \u116 \
\uc0\u32 \u32 \u32 \u32 \u117 \u110 \u115 \u105 \u103 \u110 \u101 \u100 \u32 \u105 \u110 \u116 \u32 \u108 \u101 \u110 \u103 \u116 \u104 \u32 \u61 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u115 \u105 \u122 \u101 \u40 \u41 \u59 \u32 \u32 \
\uc0\u32 \u32 \u32 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u114 \u101 \u115 \u105 \u122 \u101 \u40 \u49 \u48 \u48 \u44 \u32 \u50 \u48 \u48 \u41 \u59 \
\uc0\u32 \u32 \u32 \u32 \u32 \u32 \u47 \u47 \u8230 \
\uc0\u32 \u32 \u32 \u32 \u112 \u102 \u111 \u111 \u45 \u62 \u126 \u70 \u111 \u111 \u40 \u41 \u59 \u32 \u32 \u47 \u47 \u51 \u46 \u32 \u101 \u120 \u112 \u108 \u105 \u99 \u105 \u116 \u32 \u100 \u101 \u115 \u116 \u114 \u117 \u99 \u116 \u111 \u114 \u32 \u105 \u110 \u118 \u111 \u99 \u97 \u116 \u105 \u111 \u110 \
\uc0\u32 \u32 \u32 \u32 \u100 \u101 \u108 \u101 \u116 \u101 \u32 \u91 \u93 \u32 \u98 \u117 \u102 \u102 \u59 \u32 \u32 \u47 \u47 \u52 \u46 \u32 \u114 \u101 \u108 \u101 \u97 \u115 \u101 \u32 \u112 \u114 \u101 \u45 \u97 \u108 \u108 \u111 \u99 \u97 \u116 \u101 \u100 \u32 \u98 \u117 \u102 \u102 \u101 \u114 \
\uc0\u32 \u32 \u125 \
\
\
\

\f7 Placement New/Delete\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\ql\qnatural\pardirnatural
\cf0 \
In C++, operators new/delete mostly replace the use of malloc() and free() in C. For example: \
\
        class A \{\
        public:\
                A();\
                ~A();\
        \};\
\
        A* p = new A;\
\
        ...\
\
        delete p;\
allocates storage for an A object and arranges for its constructor to be called, later followed by invocation of the destructor and freeing of the storage. You can use the standard new/delete functions in the library, or define your own globally and/or on a per-class basis. \
\
There's a variation on new/delete worth mentioning. It's possible to supply additional parameters to a new call, for example: \
\
        A* p = new (a, b) A;\
where a and b are arbitrary expressions; this is known as "placement new". For example, suppose that you have an object instance of a specialized class named Alloc that you want to pass to the new operator, so that new can control allocation according to the state of this object (that is, a specialized storage allocator): \
\
        class Alloc \{/* stuff */\};\
\
        Alloc allocator;\
\
        ...\
\
        class A \{/* stuff */\};\
\
        ...\
\
        A* p = new (allocator) A;\
If you do this, then you need to define your own new function, like this: \
\
        void* operator new(size_t s, Alloc& a)\
        \{\
                // stuff\
        \}\
The first parameter is always of type "size_t" (typically unsigned int), and any additional parameters are then listed. In this example, the "a" instance of Alloc might be examined to determine what strategy to use to allocate space. A similar approach can be used for operator new[] used for arrays. \
\
This feature has been around for a while. A relatively new feature that goes along with it is placement delete. If during object initialization as part of a placement new call, for example during constructor invocation on a class object instance, an exception is thrown, then a matching placement delete call is made, with the same arguments and values as to placement new. In the example above, a matching function would be: \
\
        void operator delete(void* p, Alloc& a)\
        \{\
                // stuff\
        \}\
With new, the first parameter is always "size_t", and with delete, always "void*". So "matching" in this instance means all other parameters match. "a" would have the value as was passed to new earlier. \
\
Here's a simple example: \
\
        int flag = 0;\
\
        typedef unsigned int size_t;\
\
        void operator delete(void* p, int i)\
        \{\
                flag = 1;\
        \}\
\
        void* operator new(size_t s, int i)\
        \{\
                return new char[s];\
        \}\
\
        class A \{\
        public:\
                A() \{throw -37;\}\
        \};\
\
        int main()\
        \{\
                try \{\
                        A* p = new (1234) A;\
                \}\
                catch (int i) \{\
                \}\
                if (flag == 0)\
                        return 1;\
                else\
                        return 0;\
        \}\
Placement delete may not be in your local C++ compiler as yet. In compilers without this feature, memory will leak. Note also that you can't call overloaded operator delete directly via the operator syntax; you'd have to code it as a regular function call. \
}